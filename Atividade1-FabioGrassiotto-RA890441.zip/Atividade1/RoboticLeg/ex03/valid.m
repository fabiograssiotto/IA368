v2 = JBF*dq

if (v == v2)
    disp('CORRECT');
else
    disp('INCORRECT');
end