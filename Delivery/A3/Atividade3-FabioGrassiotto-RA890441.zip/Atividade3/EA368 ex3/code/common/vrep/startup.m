% add current directory and all sub directories to path
path = genpath( pwd ); 
addpath( path ) 

